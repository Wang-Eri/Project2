﻿CREATE TABLE books
(
	[accNo] INT NOT NULL PRIMARY KEY, 
    [isbn] VARCHAR(50) NULL, 
    [name] VARCHAR(50) NULL, 
    [author] VARCHAR(50) NULL, 
    [publisher] VARCHAR(50) NULL, 
    [dld] INT NULL, 
    [borrower] INT NULL, 
    CONSTRAINT [FK_books_ToTable] FOREIGN KEY (dld) REFERENCES department(dep_ld), 
    CONSTRAINT [FK_books_ToTable_1] FOREIGN KEY (borrower) REFERENCES borrowers(brld)

)
