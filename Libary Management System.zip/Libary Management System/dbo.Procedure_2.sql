﻿CREATE PROCEDURE [dbo].BooksAdd_SP
	@accNo int,
	@ISBN varchar(30),
    @Name varchar(30),
	@Author varchar(30),
	@Publisher varchar(30),
	@Did int
	
	
	
AS
	insert into books(accNo,ISBN,Name,Author,Publisher,Did) values(@accNo,@ISBN,@Name,@Author,@Publisher,@Did)
RETURN 0
