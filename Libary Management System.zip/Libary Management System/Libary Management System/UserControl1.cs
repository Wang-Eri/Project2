﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Libary_Management_System
{
    public partial class Add_Books_UserControl1 : UserControl
    {
        private static Add_Books_UserControl1 _instance;

      

        public static Add_Books_UserControl1 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Add_Books_UserControl1();
                }
                return _instance;
            }

        }
        public Add_Books_UserControl1()
        {
        
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

        }
    }


}
