﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Libary_Management_System
{

    public partial class Books_UserControl1 : UserControl
    {
        private static Books_UserControl1 _instance;

        public static Books_UserControl1 Instance {
           get
        {
    if (_instance ==null){
        _instance= new Books_UserControl1();
}
return _instance;
    }
}


        public Books_UserControl1()
        {
            InitializeComponent();
        }


        SqlConnection con=new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security = True");
        private void Books_UserControl1_Load(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("BooksAdd_SP", con);

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@accNo", Acc_N0_textB.Text);
            cmd.Parameters.AddWithValue("@isbn", ISBN_textBox4.Text);
            cmd.Parameters.AddWithValue("@name", Name_textBox3.Text);
            cmd.Parameters.AddWithValue("@author", Author_textBox5.Text);
            cmd.Parameters.AddWithValue("@publisher", Publisher_textBox6.Text);
            
            cmd.Parameters.AddWithValue("@dld", Department_textBox2.Text);


            con.Open();




            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("<<< INVALID SQL OPERATION>>>: \n" + ex);
            }
            con.Close();

            refresh_DataGridView();

        }



        public void refresh_DataGridView()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAllBooksData_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("<<< INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];

            }

            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            
        }

        private void Add_Click_1(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("BooksAdd_SP", con);

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@accNo", Acc_N0_textB.Text);
            cmd.Parameters.AddWithValue("@isbn", ISBN_textBox4.Text);
            cmd.Parameters.AddWithValue("@name", Name_textBox3.Text);
            cmd.Parameters.AddWithValue("@author", Author_textBox5.Text);
            cmd.Parameters.AddWithValue("@publisher", Publisher_textBox6.Text);

            cmd.Parameters.AddWithValue("@dld", Department_textBox2.Text);


            con.Open();




            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("<<< INVALID SQL OPERATION>>>: \n" + ex);
            }
            con.Close();

            refresh_DataGridView();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Books_UserControl1_Load_1(object sender, EventArgs e)
        {
            refresh_DataGridView();
        }

        private void Update_Click(object sender, EventArgs e)
        {

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("BooksDelete_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;



                cmd.Parameters.AddWithValue("@accNo", Acc_N0_textB.Text);

          

                con.Open();

                try
                {
                    
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("<<< INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();


                refresh_DataGridView();

            }

            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }

        }

        private void Clear_Click(object sender, EventArgs e)
        {
            Book_id_textBox1.Text = "";
            Acc_N0_textB.Text = "";
            ISBN_textBox4.Text = "";
            Name_textBox3.Text = "";
            Publisher_textBox6.Text = "";
            Author_textBox5.Text = "";
            Department_textBox2.Text = "";


        }

        private void Search_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SearchBook_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@accNo", Book_id_textBox1.Text);
                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);


               
                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("<<< INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];

            }

            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }

        }

        private void Name_textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
