﻿namespace Libary_Management_System
{
    partial class Transactions_UserControll
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BorrowersIDlabel1 = new System.Windows.Forms.Label();
            this.BOOK1_label2 = new System.Windows.Forms.Label();
            this.Borrowertext_textBox1 = new System.Windows.Forms.TextBox();
            this.borrowed1_label1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.borrowed2label2 = new System.Windows.Forms.Label();
            this.search_button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.accno_textBox2 = new System.Windows.Forms.TextBox();
            this.borrowed3label3 = new System.Windows.Forms.Label();
            this.borrowed4label3 = new System.Windows.Forms.Label();
            this.searchbook = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.issue = new System.Windows.Forms.Button();
            this.return_button3 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.log = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // BorrowersIDlabel1
            // 
            this.BorrowersIDlabel1.AutoSize = true;
            this.BorrowersIDlabel1.Font = new System.Drawing.Font("Franklin Gothic Demi", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BorrowersIDlabel1.Location = new System.Drawing.Point(36, 31);
            this.BorrowersIDlabel1.Name = "BorrowersIDlabel1";
            this.BorrowersIDlabel1.Size = new System.Drawing.Size(235, 38);
            this.BorrowersIDlabel1.TabIndex = 0;
            this.BorrowersIDlabel1.Text = "Borrowers\'s ID:";
            // 
            // BOOK1_label2
            // 
            this.BOOK1_label2.AutoSize = true;
            this.BOOK1_label2.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BOOK1_label2.Location = new System.Drawing.Point(692, 21);
            this.BOOK1_label2.Name = "BOOK1_label2";
            this.BOOK1_label2.Size = new System.Drawing.Size(70, 25);
            this.BOOK1_label2.TabIndex = 1;
            this.BOOK1_label2.Text = "Book1";
            // 
            // Borrowertext_textBox1
            // 
            this.Borrowertext_textBox1.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Borrowertext_textBox1.Location = new System.Drawing.Point(302, 21);
            this.Borrowertext_textBox1.Multiline = true;
            this.Borrowertext_textBox1.Name = "Borrowertext_textBox1";
            this.Borrowertext_textBox1.Size = new System.Drawing.Size(271, 60);
            this.Borrowertext_textBox1.TabIndex = 2;
            this.Borrowertext_textBox1.TextChanged += new System.EventHandler(this.Borrowertext_textBox1_TextChanged);
            // 
            // borrowed1_label1
            // 
            this.borrowed1_label1.AutoSize = true;
            this.borrowed1_label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrowed1_label1.Location = new System.Drawing.Point(879, 10);
            this.borrowed1_label1.Name = "borrowed1_label1";
            this.borrowed1_label1.Size = new System.Drawing.Size(138, 25);
            this.borrowed1_label1.TabIndex = 3;
            this.borrowed1_label1.Text = "borrowered by";
            this.borrowed1_label1.UseMnemonic = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(692, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Book2";
            // 
            // borrowed2label2
            // 
            this.borrowed2label2.AutoSize = true;
            this.borrowed2label2.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrowed2label2.Location = new System.Drawing.Point(879, 82);
            this.borrowed2label2.Name = "borrowed2label2";
            this.borrowed2label2.Size = new System.Drawing.Size(138, 25);
            this.borrowed2label2.TabIndex = 5;
            this.borrowed2label2.Text = "borrowered by";
            this.borrowed2label2.UseMnemonic = false;
            // 
            // search_button1
            // 
            this.search_button1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.search_button1.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_button1.Location = new System.Drawing.Point(302, 127);
            this.search_button1.Name = "search_button1";
            this.search_button1.Size = new System.Drawing.Size(260, 55);
            this.search_button1.TabIndex = 6;
            this.search_button1.Text = "Search Borrowers";
            this.search_button1.UseVisualStyleBackColor = false;
            this.search_button1.Click += new System.EventHandler(this.search_button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Demi", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 235);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 38);
            this.label2.TabIndex = 8;
            this.label2.Text = "Acc No:";
            // 
            // accno_textBox2
            // 
            this.accno_textBox2.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accno_textBox2.Location = new System.Drawing.Point(302, 237);
            this.accno_textBox2.Multiline = true;
            this.accno_textBox2.Name = "accno_textBox2";
            this.accno_textBox2.Size = new System.Drawing.Size(271, 60);
            this.accno_textBox2.TabIndex = 9;
            // 
            // borrowed3label3
            // 
            this.borrowed3label3.AutoSize = true;
            this.borrowed3label3.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrowed3label3.Location = new System.Drawing.Point(692, 247);
            this.borrowed3label3.Name = "borrowed3label3";
            this.borrowed3label3.Size = new System.Drawing.Size(138, 25);
            this.borrowed3label3.TabIndex = 10;
            this.borrowed3label3.Text = "borrowered by";
            this.borrowed3label3.UseMnemonic = false;
            // 
            // borrowed4label3
            // 
            this.borrowed4label3.AutoSize = true;
            this.borrowed4label3.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrowed4label3.Location = new System.Drawing.Point(904, 250);
            this.borrowed4label3.Name = "borrowed4label3";
            this.borrowed4label3.Size = new System.Drawing.Size(113, 25);
            this.borrowed4label3.TabIndex = 11;
            this.borrowed4label3.Text = "borrowered";
            this.borrowed4label3.UseMnemonic = false;
            // 
            // searchbook
            // 
            this.searchbook.BackColor = System.Drawing.Color.LightSeaGreen;
            this.searchbook.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchbook.Location = new System.Drawing.Point(178, 327);
            this.searchbook.Name = "searchbook";
            this.searchbook.Size = new System.Drawing.Size(264, 58);
            this.searchbook.TabIndex = 12;
            this.searchbook.Text = "Search Book";
            this.searchbook.UseVisualStyleBackColor = false;
            this.searchbook.Click += new System.EventHandler(this.searchbook_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.LightSeaGreen;
            this.clear.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(697, 327);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(292, 58);
            this.clear.TabIndex = 13;
            this.clear.Text = "Clear all";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // issue
            // 
            this.issue.BackColor = System.Drawing.Color.LightSeaGreen;
            this.issue.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.issue.Location = new System.Drawing.Point(178, 422);
            this.issue.Name = "issue";
            this.issue.Size = new System.Drawing.Size(264, 59);
            this.issue.TabIndex = 14;
            this.issue.Text = "Issue Book";
            this.issue.UseVisualStyleBackColor = false;
            this.issue.Click += new System.EventHandler(this.issue_Click);
            // 
            // return_button3
            // 
            this.return_button3.BackColor = System.Drawing.Color.LightSeaGreen;
            this.return_button3.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_button3.Location = new System.Drawing.Point(697, 422);
            this.return_button3.Name = "return_button3";
            this.return_button3.Size = new System.Drawing.Size(292, 59);
            this.return_button3.TabIndex = 15;
            this.return_button3.Text = "Return Book";
            this.return_button3.UseVisualStyleBackColor = false;
            this.return_button3.Click += new System.EventHandler(this.return_button3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(178, 598);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(778, 124);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // log
            // 
            this.log.BackColor = System.Drawing.Color.LightSeaGreen;
            this.log.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log.Location = new System.Drawing.Point(436, 520);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(264, 58);
            this.log.TabIndex = 17;
            this.log.Text = "show log of tran";
            this.log.UseVisualStyleBackColor = false;
            this.log.Click += new System.EventHandler(this.log_Click);
            // 
            // Transactions_UserControll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.log);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.return_button3);
            this.Controls.Add(this.issue);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.searchbook);
            this.Controls.Add(this.borrowed4label3);
            this.Controls.Add(this.borrowed3label3);
            this.Controls.Add(this.accno_textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.search_button1);
            this.Controls.Add(this.borrowed2label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.borrowed1_label1);
            this.Controls.Add(this.Borrowertext_textBox1);
            this.Controls.Add(this.BOOK1_label2);
            this.Controls.Add(this.BorrowersIDlabel1);
            this.Name = "Transactions_UserControll";
            this.Size = new System.Drawing.Size(1074, 747);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label BorrowersIDlabel1;
        private System.Windows.Forms.Label BOOK1_label2;
        private System.Windows.Forms.TextBox Borrowertext_textBox1;
        private System.Windows.Forms.Label borrowed1_label1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label borrowed2label2;
        private System.Windows.Forms.Button search_button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox accno_textBox2;
        private System.Windows.Forms.Label borrowed3label3;
        private System.Windows.Forms.Label borrowed4label3;
        private System.Windows.Forms.Button searchbook;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button issue;
        private System.Windows.Forms.Button return_button3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button log;
    }
}
