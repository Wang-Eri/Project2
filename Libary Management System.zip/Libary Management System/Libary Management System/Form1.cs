﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Libary_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        private string getUsername()
        {
            con.Open();
            string syntax = "SELECT Value FROM systemTable where Property='Username'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string temp = dr[0].ToString();
            con.Close();
          return temp;


        }


        private string getPassword()
        {
            con.Open();
            string syntax = "SELECT Value FROM systemTable where Property='Password'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string temp = dr[0].ToString();
            con.Close();
            return temp;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string uname = getUsername(), upass=getPassword(), name, pass;
            name = username.Text;
            pass = userpass.Text;

            if (uname.Equals(name) && upass.Equals(pass))
            {
                
                AppBody obj = new AppBody();
                this.Hide();
                obj.Show();


            }
            else
            {
                MessageBox.Show("Sorry,incorrect username or password");
            }

        }

        private void username_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
