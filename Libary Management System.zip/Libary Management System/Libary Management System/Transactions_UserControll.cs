﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Libary_Management_System
{
    public partial class Transactions_UserControll : UserControl
    {
        private static Transactions_UserControll _instance;

        public static Transactions_UserControll Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Transactions_UserControll();
                }
                return _instance;
            }
        }
        public Transactions_UserControll()
        {

            InitializeComponent();
        }
      

        public string Book1, Book2, Borrower;

        SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security = True");
        public SqlCommand cmd;
        public SqlDataReader dr;

     

        private void searchbook_Click(object sender, EventArgs e)
        {
            con.Open();
            String syntax = "SELECT borrower FROM books where accNO='" + accno_textBox2.Text + "'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            borrowed4label3.Text = Borrower = dr[0].ToString();
            con.Close();

        }

        

        private void search_button1_Click(object sender, EventArgs e)
        {
            con.Open();
            String syntax = "SELECT Book1 FROM Borrowers where Brld='" + Borrowertext_textBox1.Text + "'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            borrowed1_label1.Text = Book1 = dr[0].ToString();
            con.Close();
            //to get books2
            con.Open();
            syntax = "SELECT Book2 FROM Borrowers where Brld='" + Borrowertext_textBox1.Text + "'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            borrowed2label2.Text = Book2 = dr[0].ToString();
            con.Close();


        }

        private void clear_Click(object sender, EventArgs e)
        {
            Borrowertext_textBox1.Text = "";
            accno_textBox2.Text = "";
        }

        private void Borrowertext_textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



       

        private void log_Click(object sender, EventArgs e)
        {
            
            refresh_DataGridView();
        }
        public void refresh_DataGridView()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAll_transaction_Sp", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("<<< INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];

            }

            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }

        }

        private void issue_Click(object sender, EventArgs e)
        {
            search_button1.PerformClick();

            if (Borrower != "")
            {
                MessageBox.Show("Book is already borrowed by some other Borrower with borrower id : \n" + Borrower);
                return;
            }
            search_button1.PerformClick();
            if ((Book1 !="")&& (Book2 != ""))
            {
                MessageBox.Show(" borrower has already borrowed maximum number of books.");
                return;

            }


            try
            {
                if (Book1 == "")
                {
                    cmd = new SqlCommand("Transact_Update_Books1_SP", con);
                }
                else {
                    cmd = new SqlCommand("Transact_Update_Books2_SP", con);

                }
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@accNo", accno_textBox2.Text);
                cmd.Parameters.AddWithValue("@brld", Borrowertext_textBox1.Text);
                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<< INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

            }
            catch( Exception ex)
            {
                MessageBox.Show("" + ex); 

            }

            cmd = new SqlCommand("Transact_Update_Borrower_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@accNo", accno_textBox2.Text);
            cmd.Parameters.AddWithValue("@brld", Borrowertext_textBox1.Text);


            cmd = new SqlCommand("transactions_insert_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@bkid", accno_textBox2.Text);
            cmd.Parameters.AddWithValue("@brid", Borrowertext_textBox1.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" <<< INVALID SQL OPERATION>>>: \n" + ex);
            }
            con.Close();



            search_button1.PerformClick();
            searchbook.PerformClick();
            MessageBox.Show("Successfully issued");

        }

        private void return_button3_Click(object sender, EventArgs e)
        {
            searchbook.PerformClick();
            search_button1.PerformClick();

            if (accno_textBox2.Text!=Book1 && accno_textBox2.Text != Book2)
            {
                MessageBox.Show("The borrower has not borrowed the book");
                return;
            }
          
        


            try
            {
                if (Book1 == accno_textBox2.Text)
                {
                    cmd = new SqlCommand("Transact_Update_Books1_SP", con);
                }
                else
                {
                    cmd = new SqlCommand("Transact_Update_Books2_SP", con);

                }
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@accNo",(object)DBNull.Value);
                cmd.Parameters.AddWithValue("@brld", Borrowertext_textBox1.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);

            }

            cmd = new SqlCommand("Transact_Update_Borrower_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@accNo", accno_textBox2.Text);
            cmd.Parameters.AddWithValue("@brld", (object)DBNull.Value);


            cmd = new SqlCommand("transactions_delete_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.AddWithValue("@bkid", accno_textBox2.Text);
            cmd.Parameters.AddWithValue("@brid", Borrowertext_textBox1.Text);



            con.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" <<< INVALID SQL OPERATION>>>: \n" + ex);
            }
            con.Close();

            search_button1.PerformClick();
            searchbook.PerformClick();
            MessageBox.Show("Successfully returned");

        }

    }




}

