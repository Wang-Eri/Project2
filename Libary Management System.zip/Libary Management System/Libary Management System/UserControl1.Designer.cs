﻿namespace Libary_Management_System
{
    partial class Add_Books_UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernmae_text = new System.Windows.Forms.TextBox();
            this.password_text = new System.Windows.Forms.TextBox();
            this.ACCNO_label = new System.Windows.Forms.Label();
            this.ISBN_label = new System.Windows.Forms.Label();
            this.Dld_label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // usernmae_text
            // 
            this.usernmae_text.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernmae_text.Location = new System.Drawing.Point(410, 322);
            this.usernmae_text.Multiline = true;
            this.usernmae_text.Name = "usernmae_text";
            this.usernmae_text.Size = new System.Drawing.Size(153, 47);
            this.usernmae_text.TabIndex = 0;
            // 
            // password_text
            // 
            this.password_text.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_text.Location = new System.Drawing.Point(410, 402);
            this.password_text.Multiline = true;
            this.password_text.Name = "password_text";
            this.password_text.Size = new System.Drawing.Size(153, 47);
            this.password_text.TabIndex = 1;
            // 
            // ACCNO_label
            // 
            this.ACCNO_label.AutoSize = true;
            this.ACCNO_label.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ACCNO_label.Location = new System.Drawing.Point(210, 322);
            this.ACCNO_label.Name = "ACCNO_label";
            this.ACCNO_label.Size = new System.Drawing.Size(101, 25);
            this.ACCNO_label.TabIndex = 7;
            this.ACCNO_label.Text = "Username";
            // 
            // ISBN_label
            // 
            this.ISBN_label.AutoSize = true;
            this.ISBN_label.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ISBN_label.Location = new System.Drawing.Point(210, 405);
            this.ISBN_label.Name = "ISBN_label";
            this.ISBN_label.Size = new System.Drawing.Size(96, 25);
            this.ISBN_label.TabIndex = 8;
            this.ISBN_label.Text = "Password";
            // 
            // Dld_label6
            // 
            this.Dld_label6.AutoSize = true;
            this.Dld_label6.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dld_label6.Location = new System.Drawing.Point(244, 514);
            this.Dld_label6.Name = "Dld_label6";
            this.Dld_label6.Size = new System.Drawing.Size(0, 25);
            this.Dld_label6.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 37);
            this.label1.TabIndex = 13;
            this.label1.Text = "New Account\r\n";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button1.Location = new System.Drawing.Point(846, 598);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 73);
            this.button1.TabIndex = 14;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Add_Books_UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Dld_label6);
            this.Controls.Add(this.ISBN_label);
            this.Controls.Add(this.ACCNO_label);
            this.Controls.Add(this.password_text);
            this.Controls.Add(this.usernmae_text);
            this.Name = "Add_Books_UserControl1";
            this.Size = new System.Drawing.Size(1074, 747);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox usernmae_text;
        private System.Windows.Forms.TextBox password_text;
        private System.Windows.Forms.Label ACCNO_label;
        private System.Windows.Forms.Label ISBN_label;
        private System.Windows.Forms.Label Dld_label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}
