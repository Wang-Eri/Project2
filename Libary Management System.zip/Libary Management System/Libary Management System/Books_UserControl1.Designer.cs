﻿namespace Libary_Management_System
{
    partial class Books_UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.Book_id_textBox1 = new System.Windows.Forms.TextBox();
            this.Clear = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.Update = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Search = new System.Windows.Forms.Button();
            this.Acc = new System.Windows.Forms.Label();
            this.Acc_N0_textB = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.Name_textBox3 = new System.Windows.Forms.TextBox();
            this.ISBN = new System.Windows.Forms.Label();
            this.ISBN_textBox4 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Author_textBox5 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Publisher_textBox6 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Department_textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(188, 161);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(778, 146);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(144, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Book ID: ";
            // 
            // Book_id_textBox1
            // 
            this.Book_id_textBox1.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Book_id_textBox1.Location = new System.Drawing.Point(325, 54);
            this.Book_id_textBox1.Multiline = true;
            this.Book_id_textBox1.Name = "Book_id_textBox1";
            this.Book_id_textBox1.Size = new System.Drawing.Size(183, 41);
            this.Book_id_textBox1.TabIndex = 2;
            // 
            // Clear
            // 
            this.Clear.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Clear.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.ForeColor = System.Drawing.Color.White;
            this.Clear.Image = global::Libary_Management_System.Properties.Resources.broom;
            this.Clear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Clear.Location = new System.Drawing.Point(823, 361);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(241, 59);
            this.Clear.TabIndex = 7;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = false;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Delete.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.ForeColor = System.Drawing.Color.White;
            this.Delete.Image = global::Libary_Management_System.Properties.Resources.garbage;
            this.Delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Delete.Location = new System.Drawing.Point(545, 361);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(237, 59);
            this.Delete.TabIndex = 6;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Update
            // 
            this.Update.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Update.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update.ForeColor = System.Drawing.Color.White;
            this.Update.Image = global::Libary_Management_System.Properties.Resources.update;
            this.Update.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Update.Location = new System.Drawing.Point(268, 361);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(240, 59);
            this.Update.TabIndex = 5;
            this.Update.Text = "Update";
            this.Update.UseVisualStyleBackColor = false;
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Add.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.ForeColor = System.Drawing.Color.White;
            this.Add.Image = global::Libary_Management_System.Properties.Resources.add;
            this.Add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add.Location = new System.Drawing.Point(19, 361);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(222, 59);
            this.Add.TabIndex = 4;
            this.Add.Text = "Add new";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click_1);
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Search.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.Color.White;
            this.Search.Image = global::Libary_Management_System.Properties.Resources.search;
            this.Search.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Search.Location = new System.Drawing.Point(623, 44);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(295, 59);
            this.Search.TabIndex = 3;
            this.Search.Text = "Search Books";
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // Acc
            // 
            this.Acc.AutoSize = true;
            this.Acc.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Acc.Location = new System.Drawing.Point(127, 485);
            this.Acc.Name = "Acc";
            this.Acc.Size = new System.Drawing.Size(104, 34);
            this.Acc.TabIndex = 8;
            this.Acc.Text = "Acc No:";
            // 
            // Acc_N0_textB
            // 
            this.Acc_N0_textB.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Acc_N0_textB.Location = new System.Drawing.Point(269, 489);
            this.Acc_N0_textB.Multiline = true;
            this.Acc_N0_textB.Name = "Acc_N0_textB";
            this.Acc_N0_textB.Size = new System.Drawing.Size(183, 41);
            this.Acc_N0_textB.TabIndex = 9;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(127, 580);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(90, 34);
            this.name.TabIndex = 10;
            this.name.Text = "Name:";
            // 
            // Name_textBox3
            // 
            this.Name_textBox3.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_textBox3.Location = new System.Drawing.Point(268, 580);
            this.Name_textBox3.Multiline = true;
            this.Name_textBox3.Name = "Name_textBox3";
            this.Name_textBox3.Size = new System.Drawing.Size(183, 41);
            this.Name_textBox3.TabIndex = 11;
            this.Name_textBox3.TextChanged += new System.EventHandler(this.Name_textBox3_TextChanged);
            // 
            // ISBN
            // 
            this.ISBN.AutoSize = true;
            this.ISBN.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ISBN.Location = new System.Drawing.Point(572, 493);
            this.ISBN.Name = "ISBN";
            this.ISBN.Size = new System.Drawing.Size(81, 34);
            this.ISBN.TabIndex = 12;
            this.ISBN.Text = "ISBN:";
            // 
            // ISBN_textBox4
            // 
            this.ISBN_textBox4.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ISBN_textBox4.Location = new System.Drawing.Point(763, 485);
            this.ISBN_textBox4.Multiline = true;
            this.ISBN_textBox4.Name = "ISBN_textBox4";
            this.ISBN_textBox4.Size = new System.Drawing.Size(183, 41);
            this.ISBN_textBox4.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(127, 685);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 34);
            this.label2.TabIndex = 14;
            this.label2.Text = "Author:";
            // 
            // Author_textBox5
            // 
            this.Author_textBox5.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Author_textBox5.Location = new System.Drawing.Point(268, 678);
            this.Author_textBox5.Multiline = true;
            this.Author_textBox5.Name = "Author_textBox5";
            this.Author_textBox5.Size = new System.Drawing.Size(183, 41);
            this.Author_textBox5.TabIndex = 15;
            this.Author_textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(572, 576);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 34);
            this.label3.TabIndex = 16;
            this.label3.Text = "Publisher:";
            // 
            // Publisher_textBox6
            // 
            this.Publisher_textBox6.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Publisher_textBox6.Location = new System.Drawing.Point(763, 569);
            this.Publisher_textBox6.Multiline = true;
            this.Publisher_textBox6.Name = "Publisher_textBox6";
            this.Publisher_textBox6.Size = new System.Drawing.Size(183, 41);
            this.Publisher_textBox6.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(572, 685);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 34);
            this.label4.TabIndex = 18;
            this.label4.Text = "Department:";
            // 
            // Department_textBox2
            // 
            this.Department_textBox2.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Department_textBox2.Location = new System.Drawing.Point(763, 685);
            this.Department_textBox2.Multiline = true;
            this.Department_textBox2.Name = "Department_textBox2";
            this.Department_textBox2.Size = new System.Drawing.Size(183, 41);
            this.Department_textBox2.TabIndex = 19;
            // 
            // Books_UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.Department_textBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Publisher_textBox6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Author_textBox5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ISBN_textBox4);
            this.Controls.Add(this.ISBN);
            this.Controls.Add(this.Name_textBox3);
            this.Controls.Add(this.name);
            this.Controls.Add(this.Acc_N0_textB);
            this.Controls.Add(this.Acc);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.Book_id_textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Books_UserControl1";
            this.Size = new System.Drawing.Size(1074, 747);
            this.Load += new System.EventHandler(this.Books_UserControl1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Book_id_textBox1;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Label Acc;
        private System.Windows.Forms.TextBox Acc_N0_textB;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox Name_textBox3;
        private System.Windows.Forms.Label ISBN;
        private System.Windows.Forms.TextBox ISBN_textBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Author_textBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Publisher_textBox6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Department_textBox2;
    }
}
