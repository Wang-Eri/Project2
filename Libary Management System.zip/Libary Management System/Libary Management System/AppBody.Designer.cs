﻿namespace Libary_Management_System
{
    partial class AppBody
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AppBody));
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SlidingPannel = new System.Windows.Forms.Panel();
            this.BooksTabButton = new System.Windows.Forms.Button();
            this.BorrowersTabButton = new System.Windows.Forms.Button();
            this.TransactionTabButton = new System.Windows.Forms.Button();
            this.SettingsTabButton = new System.Windows.Forms.Button();
            this.AboutTabButton = new System.Windows.Forms.Button();
            this.SlidingPannel_ToggleButton = new System.Windows.Forms.Button();
            this.SliddingPannel_Timer = new System.Windows.Forms.Timer(this.components);
            this.ContentPannel = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.SlidingPannel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1510, 55);
            this.panel2.TabIndex = 0;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button1.Location = new System.Drawing.Point(1384, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 52);
            this.button1.TabIndex = 4;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button4.Location = new System.Drawing.Point(1452, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(55, 52);
            this.button4.TabIndex = 5;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button5.Location = new System.Drawing.Point(1327, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(62, 52);
            this.button5.TabIndex = 3;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // SlidingPannel
            // 
            this.SlidingPannel.BackColor = System.Drawing.Color.LightSeaGreen;
            this.SlidingPannel.Controls.Add(this.BooksTabButton);
            this.SlidingPannel.Controls.Add(this.BorrowersTabButton);
            this.SlidingPannel.Controls.Add(this.TransactionTabButton);
            this.SlidingPannel.Controls.Add(this.SettingsTabButton);
            this.SlidingPannel.Controls.Add(this.AboutTabButton);
            this.SlidingPannel.Controls.Add(this.SlidingPannel_ToggleButton);
            this.SlidingPannel.Dock = System.Windows.Forms.DockStyle.Left;
            this.SlidingPannel.Location = new System.Drawing.Point(0, 55);
            this.SlidingPannel.Name = "SlidingPannel";
            this.SlidingPannel.Size = new System.Drawing.Size(274, 749);
            this.SlidingPannel.TabIndex = 1;
            // 
            // BooksTabButton
            // 
            this.BooksTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BooksTabButton.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BooksTabButton.Image = global::Libary_Management_System.Properties.Resources._1;
            this.BooksTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BooksTabButton.Location = new System.Drawing.Point(-3, 54);
            this.BooksTabButton.Name = "BooksTabButton";
            this.BooksTabButton.Size = new System.Drawing.Size(274, 57);
            this.BooksTabButton.TabIndex = 7;
            this.BooksTabButton.Text = "BOOKS";
            this.BooksTabButton.UseVisualStyleBackColor = true;
            this.BooksTabButton.Click += new System.EventHandler(this.BooksTabButton_Click);
            // 
            // BorrowersTabButton
            // 
            this.BorrowersTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BorrowersTabButton.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BorrowersTabButton.Image = global::Libary_Management_System.Properties.Resources.a;
            this.BorrowersTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BorrowersTabButton.Location = new System.Drawing.Point(0, 107);
            this.BorrowersTabButton.Name = "BorrowersTabButton";
            this.BorrowersTabButton.Size = new System.Drawing.Size(274, 57);
            this.BorrowersTabButton.TabIndex = 6;
            this.BorrowersTabButton.Text = "TRANSACTION";
            this.BorrowersTabButton.UseVisualStyleBackColor = true;
            this.BorrowersTabButton.Click += new System.EventHandler(this.BorrowersTabButton_Click);
            // 
            // TransactionTabButton
            // 
            this.TransactionTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TransactionTabButton.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionTabButton.Image = global::Libary_Management_System.Properties.Resources.b;
            this.TransactionTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TransactionTabButton.Location = new System.Drawing.Point(0, 159);
            this.TransactionTabButton.Name = "TransactionTabButton";
            this.TransactionTabButton.Size = new System.Drawing.Size(274, 57);
            this.TransactionTabButton.TabIndex = 5;
            this.TransactionTabButton.Text = "BORROWER";
            this.TransactionTabButton.UseVisualStyleBackColor = true;
            this.TransactionTabButton.Click += new System.EventHandler(this.TransactionTabButton_Click);
            // 
            // SettingsTabButton
            // 
            this.SettingsTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SettingsTabButton.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsTabButton.Image = global::Libary_Management_System.Properties.Resources.c;
            this.SettingsTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SettingsTabButton.Location = new System.Drawing.Point(0, 213);
            this.SettingsTabButton.Name = "SettingsTabButton";
            this.SettingsTabButton.Size = new System.Drawing.Size(274, 57);
            this.SettingsTabButton.TabIndex = 4;
            this.SettingsTabButton.Text = "ADD BOOKS";
            this.SettingsTabButton.UseVisualStyleBackColor = true;
            this.SettingsTabButton.Click += new System.EventHandler(this.SettingsTabButton_Click);
            // 
            // AboutTabButton
            // 
            this.AboutTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AboutTabButton.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AboutTabButton.Image = global::Libary_Management_System.Properties.Resources.f;
            this.AboutTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AboutTabButton.Location = new System.Drawing.Point(0, 267);
            this.AboutTabButton.Name = "AboutTabButton";
            this.AboutTabButton.Size = new System.Drawing.Size(274, 57);
            this.AboutTabButton.TabIndex = 3;
            this.AboutTabButton.Text = "ABOUT";
            this.AboutTabButton.UseVisualStyleBackColor = true;
            this.AboutTabButton.Click += new System.EventHandler(this.AboutTabButton_Click);
            // 
            // SlidingPannel_ToggleButton
            // 
            this.SlidingPannel_ToggleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SlidingPannel_ToggleButton.Image = global::Libary_Management_System.Properties.Resources.right;
            this.SlidingPannel_ToggleButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.SlidingPannel_ToggleButton.Location = new System.Drawing.Point(0, 0);
            this.SlidingPannel_ToggleButton.Name = "SlidingPannel_ToggleButton";
            this.SlidingPannel_ToggleButton.Size = new System.Drawing.Size(274, 57);
            this.SlidingPannel_ToggleButton.TabIndex = 2;
            this.SlidingPannel_ToggleButton.UseVisualStyleBackColor = true;
            this.SlidingPannel_ToggleButton.Click += new System.EventHandler(this.SlidingPannel_ToggleButton_Click);
            // 
            // SliddingPannel_Timer
            // 
            this.SliddingPannel_Timer.Tick += new System.EventHandler(this.SliddingPannel_Timer_Tick);
            // 
            // ContentPannel
            // 
            this.ContentPannel.Dock = System.Windows.Forms.DockStyle.Right;
            this.ContentPannel.Location = new System.Drawing.Point(269, 55);
            this.ContentPannel.Name = "ContentPannel";
            this.ContentPannel.Size = new System.Drawing.Size(1241, 749);
            this.ContentPannel.TabIndex = 2;
            this.ContentPannel.Paint += new System.Windows.Forms.PaintEventHandler(this.ContentPannel_Paint);
            // 
            // AppBody
            // 
            this.ClientSize = new System.Drawing.Size(1510, 804);
            this.Controls.Add(this.ContentPannel);
            this.Controls.Add(this.SlidingPannel);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AppBody";
            this.panel2.ResumeLayout(false);
            this.SlidingPannel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer Log_inTimer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel SlidingPannel;
        private System.Windows.Forms.Button SlidingPannel_ToggleButton;
        private System.Windows.Forms.Timer SliddingPannel_Timer;
        private System.Windows.Forms.Button BooksTabButton;
        private System.Windows.Forms.Button BorrowersTabButton;
        private System.Windows.Forms.Button TransactionTabButton;
        private System.Windows.Forms.Button SettingsTabButton;
        private System.Windows.Forms.Button AboutTabButton;
        private System.Windows.Forms.Panel ContentPannel;
    }
}