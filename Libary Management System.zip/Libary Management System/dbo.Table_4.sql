﻿CREATE TABLE transactions
(
	[Tnum] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Date] DATE NULL, 
    [Time] TIME NULL, 
    [Br_id] INT NULL, 
    [Book_num] INT NULL, 
    [Authorized_by] VARCHAR(50) NULL, 
    [Return_date] DATE NULL, 
    [hasReturned] BIT NULL, 
    CONSTRAINT [FK_transactions_ToTable] FOREIGN KEY (Br_id) REFERENCES Borrowers(Brld), 
    CONSTRAINT [FK_transactions_ToTable_1] FOREIGN KEY (Book_num) REFERENCES books(accNo)
)
